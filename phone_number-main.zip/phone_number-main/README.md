# Phone Number

This package is deprecated. Take a look on this GitHub issue for more details: https://github.com/flutter-form-builder-ecosystem/phone_number/issues/86#issuecomment-1779249119

Sorry for the inconvenience. If you want to take over this package, please contact me.
